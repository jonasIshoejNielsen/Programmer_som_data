// micro-C example 1

void main(int n) {
  /*if(11 > 22) {print 1;}
  if(11 <= 22) {print 2;}
  if(11 != 22) {print 3;}
  
  if(11 <= 22) {print 4;}
  */
  print 11 <= 22 ? 1 : 2;
/*
  while (n > 0) {
    print n;
    n = n - 1;
  }
  println;
  */
}
