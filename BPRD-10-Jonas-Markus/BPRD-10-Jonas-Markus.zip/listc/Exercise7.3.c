// micro-C example 4 -- compute and print array of factorials

void main(int n) { 
  int sum;
  sum = 0;
  int i;
  for (i=0; i<10; i=i+1)
    sum = sum+i;
  print sum;
}


