// micro-C example 4 -- compute and print array of factorials

int a[20];			/* Must be global */

void main(int n) { 
  int i;
  i = 1 ? 11 : 12;
  print i;
}
