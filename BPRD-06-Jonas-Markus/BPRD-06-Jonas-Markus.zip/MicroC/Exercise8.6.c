// micro-C example 4 -- compute and print array of factorials

int a[20];			/* Must be global */

void main(int n) { 
  int i;
  i = 0;
  int x;
  x = 2;
  switch (++x) {
    case 1: {++i;}
    case 2: {++i; ++i;}
    case 3: {++i; ++i; ++i; print 1111111;} 
    case 4: {++i;}
  }


  print i;
}
