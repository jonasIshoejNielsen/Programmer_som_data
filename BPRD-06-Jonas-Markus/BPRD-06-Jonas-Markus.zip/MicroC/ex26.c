// micro-C example 26

void main(int n) {
  int i;
  i=0;
  print i;
  int j;
  j=42;
  print j;
  println;
}
