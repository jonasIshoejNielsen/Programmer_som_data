// micro-C example 4 -- compute and print array of factorials

int a[20];			/* Must be global */

void main(int n) { 
  int i; 
  i = 0; 
  print i;
  ++i;
  print i;
  --i;
  print i;
}
