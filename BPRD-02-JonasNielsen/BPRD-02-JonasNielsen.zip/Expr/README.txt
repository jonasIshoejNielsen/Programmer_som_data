build.bat can be used to generate the necessary files.
run.bat can be used to run an interactive session.
clean.bat can be used to clean up the generated files.

Please make sure that your PATH environment variable contains a folder that contains fsi.exe, e.g. C:\Program Files (x86)\Microsoft SDKs\F#\4.0\Framework\v4.0